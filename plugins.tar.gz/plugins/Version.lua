do

function run(msg, matches)
return [[TeleNeW v8
An advanced administration bot based on TG-CLI written in Lua



#Developers
@wawi8 [ Dev ]
@hunter18k  [ Dev ]
@zainahmed98  [ Dev ]

Our channels
@iq_dev8 [ Arabic ]


http://telegram.me/iq_dev8

The github <>\ git clone https://github.com/wawi8/TeleNew.git -b supergroups
]]
end

return {
description = "Shows bot q", 
usage = "spam Shows bot q",
patterns = {
"telenew$"
},
run = run 
}
end